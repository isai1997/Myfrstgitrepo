﻿using CustomerManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagement.ViewModels
{
    public class LoginResponseViewModel
    {
        public string StatusMessage { get; set; }
        public UserLogin userLogin { get; set; }


    }
}

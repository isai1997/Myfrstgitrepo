﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagement.ViewModels
{
    public class UserView
    {
        public int UserId { get; set; }
        public string EmailId { get; set; }
        public string Name { get; set; }
        public bool IsVerified { get; set; }
    }
}

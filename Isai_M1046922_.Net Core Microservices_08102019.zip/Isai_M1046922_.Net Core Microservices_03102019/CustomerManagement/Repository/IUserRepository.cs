﻿using CustomerManagement.Models;
using CustomerManagement.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagement.Repository
{
    public interface IUserRepository
    {
        RegistrationResponseViewModel RegisterUser(UserTableClass userDetails);
        string Hash(string value);
        LoginResponseViewModel LoginUser(UserLogin userLogin);
        LoginResponseViewModel GoogleLogin(GoogleLogin googleLogin);
        string SendForgotPassword(ForgotPasswordViewModel forgotPasswordViewModel);
        ForgotPasswordViewModel ForgotPassword(ForgotPasswordViewModel forgotEmail);
        string EmailVerification(string UserId);
        string DecryptPassword(string Password);
    }
}

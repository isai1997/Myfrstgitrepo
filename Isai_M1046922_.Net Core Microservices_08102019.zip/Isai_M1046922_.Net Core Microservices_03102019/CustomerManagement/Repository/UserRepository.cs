﻿using CustomerManagement.Models;
using CustomerManagement.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Threading.Tasks;

namespace CustomerManagement.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly string BaseUrl = "https://localhost:44302/api/Customer/";
     

        /// <summary>
        /// RegisterUser method will take a model of UserTableClass class and will call the service using base address
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns>model of type RegistrationResponseViewModel</returns>
        public RegistrationResponseViewModel RegisterUser(UserTableClass userDetails)
        {
            RegistrationResponseViewModel ret = new RegistrationResponseViewModel();
            try
            {
                var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string url = "Registration";
                HttpResponseMessage response = client.PostAsJsonAsync(url, userDetails).Result;
                var responseString = response.Content.ReadAsStringAsync().Result;
                RegistrationResponseViewModel model = JsonConvert.DeserializeObject<RegistrationResponseViewModel>(responseString);
                if (model.Email != null)
                {
                    SendVerificationLinkEmail(model);   
                }

                return model;
            }
            catch (Exception ex)
            {
                ret.StatusMessage = ex.Message;
                return ret;
            }

        }
        public ForgotPasswordViewModel ForgotPassword(ForgotPasswordViewModel forgotEmail)
        {
            ForgotPasswordViewModel ret = new ForgotPasswordViewModel();
            try
            {
                var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string url = "ForgotPassword/{id}";
                HttpResponseMessage response = client.PostAsJsonAsync(url, forgotEmail).Result;
                var responseString = response.Content.ReadAsStringAsync().Result;
                ForgotPasswordViewModel model = JsonConvert.DeserializeObject<ForgotPasswordViewModel>(responseString);
                SendForgotPassword(model);
                return model;
            }
            catch (Exception ex)
            {
                ret.StatusMessage = ex.Message;
                return ret;
            }

        }
        public string Hash(string value)
        {
            try
            {
                byte[] encData_byte = new byte[value.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(value);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }


        }

        public string DecryptPassword(string Password)
        {
            try
            {
                System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                System.Text.Decoder utf8Decode = encoder.GetDecoder();
                byte[] todecode_byte = Convert.FromBase64String(Password);
                int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
                char[] decoded_char = new char[charCount];
                utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
                string result = new String(decoded_char);
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }


        }

        public LoginResponseViewModel LoginUser(UserLogin userLogin)
        {
            LoginResponseViewModel ret = new LoginResponseViewModel();
            try
            {
                var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string url = "Login";
                HttpResponseMessage response = client.PostAsJsonAsync(url, userLogin).Result;
                var responseString = response.Content.ReadAsStringAsync().Result;
                LoginResponseViewModel model = JsonConvert.DeserializeObject<LoginResponseViewModel>(responseString);
                return model;
            }
            catch (Exception ex)
            {
                ret.StatusMessage = ex.Message;
                return ret;
            }

        }

        /// <summary>
        /// GoogleLogin method will take a model of GoogleLogin class and will call the service using base address. 
        /// </summary>
        /// <param name="googleLogin"></param>
        /// <returns></returns>
        public LoginResponseViewModel GoogleLogin(GoogleLogin googleLogin)
        {
            LoginResponseViewModel ret = new LoginResponseViewModel();
            try
            {
                var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string url = "PostGoogleDetails/{id}";
                HttpResponseMessage response = client.PostAsJsonAsync(url, googleLogin).Result;
                var responseString = response.Content.ReadAsStringAsync().Result;
                LoginResponseViewModel gModel = JsonConvert.DeserializeObject<LoginResponseViewModel>(responseString);
                return gModel;
            }
            catch (Exception ex)
            {
                ret.StatusMessage = ex.Message;
                return ret;
            }

        }

        /// <summary>
        /// SendVerificationLinkEmail method will take a model of RegistrationResponseViewModel class and will send encrypted verification link to the respected email id.
        /// </summary>
        /// <param name="registerResponseViewModel"></param>
        /// <returns></returns>
        public string SendVerificationLinkEmail(RegistrationResponseViewModel registerResponseViewModel)
        {
            try
            {
                var fromEmail = new MailAddress("t2019app@gmail.com", "OMF");
                var toEmail = new MailAddress(registerResponseViewModel.Email);
                var fromEmailPassword = "User@2019";

                string subject = "OMF account successfully created!";

                string body = "Please click on the following link to verify your account on OMF https://localhost:44393/VerifyEmail?UserId=" + Hash(registerResponseViewModel.UserId.ToString());

                var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(fromEmail.Address, fromEmailPassword)
                };

                using (var message = new MailMessage(fromEmail, toEmail)
                {
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                })
                    smtp.Send(message);
                return "Email successfully sent";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }


        //-----------------------------------------------------------------Email Verification Password-----------------------------------------------------
        /// <summary>
        /// sendforgotpassword method takes a model of ForgotPasswordViewModel class and sends the particular password to the respected email id.
        /// </summary>
        /// <param name="forgotPasswordViewModel"></param>
        /// <returns></returns>

        public string SendForgotPassword(ForgotPasswordViewModel forgotPasswordViewModel)
        {
            try
            {
                var fromEmail = new MailAddress("t2019app@gmail.com", "OMF");
                var toEmail = new MailAddress(forgotPasswordViewModel.EmailId);
                var fromEmailPassword = "User@2019";
                var pass = DecryptPassword(forgotPasswordViewModel.Password);


                string subject = "Reset Password";

                string body = "Your Password is: " + pass;

                var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(fromEmail.Address, fromEmailPassword)
                };

                using (var message = new MailMessage(fromEmail, toEmail)
                {
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                })
                    smtp.Send(message);
                return "Email successfully sent.";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        //---------------------------------------------------------------------------Verify Email-------------------------------------------------------
        /// <summary>
        /// EmailVerification method will take userid in the encrypted format as parameter and decrypts it.
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns>string ans</returns>
        public string EmailVerification(string UserId)
        {
            try
            {
                var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string url = "UserVerification?userid=" + DecryptPassword(UserId);
                HttpResponseMessage response = client.GetAsync(url).Result;
                var responseString = response.Content.ReadAsStringAsync().Result;
                string ans = JsonConvert.DeserializeObject<string>(responseString);
                return ans;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
    }
}

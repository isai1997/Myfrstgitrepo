﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CustomerManagement.Models;
using CustomerManagement.Repository;
using CustomerManagement.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace CustomerManagement.Controllers
{
    public class CustomerController : Controller
    {
        IUserRepository userRepository;
        
        public CustomerController(IUserRepository _userRepository)
        {
            userRepository = _userRepository;
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult HomePage(string emailid)
        {
            
            ViewData["Username"] = new UserLogin()
            {
                EmailId  = emailid
            };
            return View();
        }
        //-----------------------------------------------------------------External Login-----------------------------------------------------

        /// <summary>
        /// External Login type is GOOGLE PLUS login which will redirect the user to the google signin page
        /// using GoogleLoginCallBack method where user will enter valid credentials after which they will
        /// be redirected to the home page on successful login.
        /// </summary>
        /// <param name="ReturnUrl"></param>
        /// <param name="type"></param>
        public ActionResult SignIn(string ReturnUrl = "/")
        {
           
            
          return Challenge(new AuthenticationProperties() { RedirectUri = "Customer/GoogleLoginCallback" },"Google");
                

        }

        [AllowAnonymous]
        public ActionResult GoogleLoginCallback()
        {
            string emailid;
            var claimsPrincipal = HttpContext.User.Identity as ClaimsIdentity;

            var loginInfo = GoogleLogin.GetLoginInfo(claimsPrincipal);
            if (loginInfo == null)
            {
                return RedirectToAction("Login", "Customer");
            }

            LoginResponseViewModel googleModel = userRepository.GoogleLogin(loginInfo);

            ViewBag.Message = googleModel.StatusMessage;

            if(googleModel.StatusMessage== "Login Successful")
            {
                 new UserLogin()
                {
                    EmailId = googleModel.userLogin.EmailId,
                    UserId = googleModel.userLogin.UserId
                };
                emailid = googleModel.userLogin.EmailId;
                return RedirectToAction("HomePage" ,new { emailid });
            }
            return View();


        }
        //-----------------------------------------------------------------Logout-----------------------------------------------------
        /// <summary>
        /// UserLogout action will clear all the session data and will redirect to the homepage
        /// </summary>
        /// <returns>redirects to homepage</returns>
        public ActionResult UserLogout()
        {
            return RedirectToAction("Login", "Customer");
        }

    }
}

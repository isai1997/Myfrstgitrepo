﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.ViewModels
{
    public class ForgotPasswordViewModel
    {
        public string UserId { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string StatusMessage { get; set; }
    }
}

﻿using CustomerManagementService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.ViewModels
{
    public class LoginResponseViewModel
    {
        public string StatusMessage { get; set; }
        public UserLogin userLogin { get; set; }
    }
}

﻿using CustomerManagementService.Models;
using CustomerManagementService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.Repository
{
    public interface IUserRepository
    {
        RegistrationResponseViewModel AddUser(UserTableClass userTableClass);
        LoginResponseViewModel LoginUser(UserLogin userLogin);
        ForgotPasswordViewModel ForgotPassword(string Email);
        string UserVerification(string UserId);
        LoginResponseViewModel GoogleLogin(GoogleLogin googleLogin);
    }
}

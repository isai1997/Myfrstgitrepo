﻿using CommonService.Models;
using CustomerManagementService.Models;
using CustomerManagementService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.Repository
{
    public class UserRepository : IUserRepository
    {
        OrdermyfoodContext db;
        public UserRepository(OrdermyfoodContext _db)
        {
            db = _db;
        }
     
        
        public RegistrationResponseViewModel AddUser(UserTableClass userTableClass)
        {
            RegistrationResponseViewModel model = new RegistrationResponseViewModel();
            try
            {
                if (userTableClass != null)
                {
                    
                        //checking whether email already exists in the database or not
                        var isEmailExist = db.Users.Where(a => a.EmailId == userTableClass.EmailId).FirstOrDefault();

                        if (isEmailExist == null)
                        {
                        db.Users.Add(new Users()
                        {
                            UserId=userTableClass.UserId,
                            EmailId = userTableClass.EmailId,
                            Name = userTableClass.Name,
                            Password = userTableClass.Password,
                            Address = userTableClass.Address,
                            City=userTableClass.City,
                                IsVerified = false
                            });
                            //saving changes to database
                            db.SaveChanges();
                            var data = (from res in db.Users
                                        where res.EmailId == userTableClass.EmailId
                                        select new { res.EmailId, res.UserId }).FirstOrDefault();
                            model.UserId = data.UserId;
                            model.Email = data.EmailId;
                            model.StatusMessage = "Registration successfully done. Account activation link has been sent to your Email ID " + model.Email;
                        }
                        else
                        {
                            model.StatusMessage = "Email Already Exist";
                        }

                    
                }
                else
                {
                    model.StatusMessage = "Input model is empty";
                }
            }
            catch (Exception ex)
            {
                model.StatusMessage = ex.Message;
            }
            return model;
        }



        /// <summary>
        /// User Login
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        public LoginResponseViewModel LoginUser(UserLogin userLogin)
        {
            LoginResponseViewModel logModel = new LoginResponseViewModel();
            try
            {
                if (userLogin != null)
                {
                   
                        // checking whether Email id is present in the database or not
                        var v = db.Users.Where(a => a.EmailId == userLogin.EmailId).FirstOrDefault();
                        if (v != null)
                        {
                            if (!v.IsVerified)
                            {
                                logModel.StatusMessage = "Email Not Verified";
                                return logModel;
                            }
                            if (string.Compare(userLogin.Password, v.Password) == 0)
                            {
                                logModel.userLogin = (from res in db.Users
                                                      where res.EmailId == userLogin.EmailId
                                                      select new UserLogin()
                                                      {
                                                          EmailId = res.EmailId,
                                                          UserId = res.UserId,
                                                        

                                                      }).FirstOrDefault();
                                logModel.StatusMessage = "Login Successful";
                                return logModel;
                            }
                            else
                            {
                                logModel.StatusMessage = "Invalid Password";
                                return logModel;
                            }
                        }
                        else
                        {
                            logModel.StatusMessage = " User account not found, please register before Login ";
                            return logModel;
                        }
                    
                }
                else
                {
                    logModel.StatusMessage = "Input model is empty";
                    return logModel;
                }

            }
            catch (Exception ex)
            {
                logModel.StatusMessage = ex.Message;
                return logModel;
            }


        }


        /// <summary>
        /// Forgot Password
        /// </summary>
        /// <param name="Email"></param>
        /// <returns></returns>
        public ForgotPasswordViewModel ForgotPassword(string Email)
        {
            ForgotPasswordViewModel passModel = new ForgotPasswordViewModel();
            try
            {
                if (!string.IsNullOrEmpty(Email))
                {
                    
                        var v = db.Users.Where(a => a.EmailId == Email).FirstOrDefault();
                        if (v != null)
                        {
                            if (!v.IsVerified)
                            {
                                passModel.StatusMessage = "Email Not Verified";
                                return passModel;
                            }
                            else
                            {
                                passModel = (from res in db.Users
                                             where res.EmailId == Email
                                             select new ForgotPasswordViewModel
                                             {
                                                 UserId = res.UserId,
                                                 EmailId = res.EmailId,
                                                 Password = res.Password
                                             }).FirstOrDefault();
                                passModel.StatusMessage = "Records found";
                                return passModel;

                            }

                        }
                        else
                        {
                            passModel.StatusMessage = "Email Id is not Present";
                            return passModel;
                        }
                    

                }
                else
                {
                    passModel.StatusMessage = "Email Id is empty";
                    return passModel;
                }
            }
            catch (Exception ex)
            {
                passModel.StatusMessage = ex.Message;
                return passModel;
            }

        }


        /// <summary>
        /// User Verifiction
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public string UserVerification(string UserId)
        {
            try
            {
                
                    var verifyUser = db.Users.Where(a => a.UserId == UserId).FirstOrDefault();
                    if (verifyUser != null)
                    {
                        db.Users.Where(a => a.UserId == UserId).ToList().ForEach(i => i.IsVerified = true);
                        db.SaveChanges();
                        return "User verified successfully";
                    }
                    else
                    {
                        return "User verification Error";
                    }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// Google Login
        /// </summary>
        /// <param name="googleLogin"></param>
        /// <returns></returns>
        public LoginResponseViewModel GoogleLogin(GoogleLogin googleLogin)
        {
            LoginResponseViewModel googleModel = new LoginResponseViewModel();

            if (googleLogin != null)
            {
                    var gUser = db.Users.Where(a => a.EmailId == googleLogin.emailaddress).FirstOrDefault();

                    if (gUser == null)
                    {
                        db.Users.Add(new Users()
                        {
                            UserId=googleLogin.givenname,
                            EmailId = googleLogin.emailaddress,
                            Name = googleLogin.givenname,
                            IsVerified = true,

                        });
                        db.SaveChanges();
                        googleModel.StatusMessage = "Login Successful";


                    }
                    googleModel.userLogin = (from res in db.Users
                                             where res.EmailId == googleLogin.emailaddress
                                             select new UserLogin()
                                             {
                                                 EmailId = res.EmailId,
                                                 UserId = res.UserId


                                             }).FirstOrDefault();
                    googleModel.StatusMessage = "Login Successful";
                    return googleModel;
                
            }
            else
            {
                googleModel.StatusMessage = "Empty Model";
            }
            return googleModel;
        }


    }
}

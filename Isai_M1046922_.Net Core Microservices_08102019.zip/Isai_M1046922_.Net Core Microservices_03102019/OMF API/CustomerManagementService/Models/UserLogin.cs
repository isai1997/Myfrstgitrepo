﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.Models
{
    public class UserLogin
    {
        public string EmailId { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerManagementService.Models
{
    public class GoogleLogin
    {
        public string loginid { get; set; }
        public string emailaddress { get; set; }
        public string givenname { get; set; }
    }
}

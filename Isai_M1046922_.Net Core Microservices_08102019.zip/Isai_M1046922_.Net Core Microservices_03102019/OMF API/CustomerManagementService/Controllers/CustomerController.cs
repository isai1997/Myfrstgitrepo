﻿
using CustomerManagementService.Models;
using CustomerManagementService.Repository;
using CustomerManagementService.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CustomerManagementService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        IUserRepository userRepository;
        public CustomerController(IUserRepository _userRepository)
        {
            userRepository = _userRepository;
        }
        /// <summary>
        /// Action for Posting User Details
        /// </summary>
        /// <param name="userTableClass"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Registration")]
        public RegistrationResponseViewModel PostUserDetails(UserTableClass userTableClass)
        {

            return userRepository.AddUser(userTableClass);

        }
        /// <summary>
        /// /Action for getting User Details aftr logging in
        /// </summary>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Login")]
        public LoginResponseViewModel GetUserDetails(UserLogin userLogin)
        {

            return userRepository.LoginUser(userLogin);

        }

        /// <summary>
        /// Forgot password action
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ForgotPassword/{id}")]
        public ForgotPasswordViewModel ForgotPassword(ForgotPasswordViewModel emailId)
        {
            string Email = emailId.EmailId;
            return userRepository.ForgotPassword(Email);
        }

        /// <summary>
        /// User Verification Action
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("UserVerification/{id}")]
        public string UserVerfication(string UserId)
        {
            return userRepository.UserVerification(UserId);
        }

        /// <summary>
        /// Post google login details
        /// </summary>
        /// <param name="googleLogin"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("PostGoogleDetails/{id}")]
        public LoginResponseViewModel PostGoogleDetails(GoogleLogin googleLogin)
        {

            return userRepository.GoogleLogin(googleLogin);

        }
    }
}
﻿using CommonService.Models;
using OrderManagementService.Models;
using OrderManagementService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagementService.Repository
{
    public class OrderRepository :IOrderRepository
    {
        OrdermyfoodContext db;
        public OrderRepository(OrdermyfoodContext _db)
        {
            db = _db;
        }
        public CartStatus Display(string UserId)   //This method is used for getting all the cart details of a user
        {                                       //and display it.
            CartStatus status = new CartStatus();
            try
            {
                
                    var query = (from cart in db.Myorder
                                 join menu in db.Menu on cart.Id equals menu.Id
                                 join res in db.Restaurant on menu.RestaurantId equals res.RestaurantId
                                 where (cart.UserId == UserId) && (cart.Itemname == menu.Itemname) && (cart.PayStatus == true) 
                                 select new CartView()
                                 {
                                     Myorderid= cart.Myorderid,
                                     Id=menu.Id,
                                     UserId = cart.UserId,
                                     Restaurantname = res.RestaurantName,
                                     Itemname=menu.Itemname,
                                     Quantity = cart.Quantity,
                                     Price = (menu.Cost * cart.Quantity)
                                 }).ToList();
                    status.statusList = query;
                    if (query.Count == 0)
                    {
                        status.statusMessage = "No Items in Cart";
                    }
                    else
                    {
                        status.statusMessage = "Items in Cart";
                    }
                
            }
            catch (Exception e)
            {
                status.statusMessage = e.Message;
            }
            return status;
        }
        public string Remove(string Myorderid)  //This method is used for removing a book from the cart.
        {
            string message;
            try
            {
               
                    Myorder myorder = db.Myorder.Find(Myorderid);
                    db.Myorder.Remove(myorder);
                    db.SaveChanges();
                    message = Myorderid + " removed from cart";
                
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            return message;
        }
        public string Buy(string UserId)  //This method is change the payment status of the items 
        {                              //in the cart when the user clicks on the buy button.
            string str;
            try
            {
                    db.Myorder.Where(u => u.UserId == UserId).ToList().ForEach(s => s.PayStatus = true);
                    db.SaveChanges();
                    str = "Payment Successfull";
               
            }
            catch (Exception e)
            {
                str = e.Message;
            }
            return str;
        }
        public string AddToCart(Cart cart)
        {
            string msg = "";
            try
            { if ((from e in db.Myorder where e.Id == cart.Id && e.UserId == cart.UserId && e.PayStatus == true select e.Myorderid).ToList().Count > 0)
                    {
                        return "Already Present";
                    }
                    else
                    {
                        db.Myorder.Add(new Myorder()
                        {
                            Myorderid=cart.Myorderid,
                            Itemname=cart.Itemname,
                            RestaurantId=cart.RestaurantId,
                            Id=cart.Id,
                            UserId = cart.UserId,
                            PayStatus = true,
                            Quantity = cart.Quantity
                        });
                        db.SaveChanges();
                        return "Added to Cart";
                    }
                
            }
            catch (Exception e)
            {
                msg = e.Message;
            }
            return msg;
        }
        //fetching details to display the invoice
        public CartStatus Invoice(string UserId)
        {
            CartStatus status = new CartStatus();
            try
            {
                var query = (from cart in db.Myorder
                             join menu in db.Menu on cart.Id equals menu.Id
                             join user in db.Users on cart.UserId equals user.UserId
                             join res in db.Restaurant on menu.RestaurantId equals res.RestaurantId
                             where (cart.UserId == UserId) && (cart.PayStatus == true)
                             select new CartView()
                             {

                                 Myorderid = cart.Myorderid,
                                 UserId = cart.UserId,
                                 Id = menu.Id,
                                     Restaurantname = res.RestaurantName,
                                     Itemname = menu.Itemname,
                                     Quantity = cart.Quantity,
                                     Price = (menu.Cost * cart.Quantity)
                                 }).ToList();
                    status.statusList = query;
                    if (query.Count == 0)
                    {
                        status.statusMessage = "Invoice unsuccessful";
                    }
                    else
                    {
                        status.statusMessage = "Invoice success";
                    }
                
            }
            catch (Exception e)
            {
                status.statusMessage = e.Message;
            }
            return status;
        }
        public string AddInvoice(InvoiceView invoiceView)
        {
            string msg = "";

            try
            {
                  if ((from e in db.PlacedOrder
                         where e.UserId == invoiceView.UserId && e.Myorderid == invoiceView.Myorderid
                         select e.PlacedOrderid).ToList().Count > 0)
                    {
                        return "Invoice is generated already";
                    }
                    else
                    {
                        db.PlacedOrder.Add(new PlacedOrder()
                        {
                            PlacedOrderid=invoiceView.PlacedOrderid,
                            UserId = invoiceView.UserId,
                            Myorderid = invoiceView.Myorderid,

                        });

                        db.SaveChanges();

                        return "Invoice Added";
                    }
                
            }
            catch (Exception e)
            {
                msg = e.Message;
            }
            return msg;
        }
    }
}

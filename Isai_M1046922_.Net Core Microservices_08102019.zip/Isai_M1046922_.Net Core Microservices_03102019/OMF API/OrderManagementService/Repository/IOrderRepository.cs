﻿using OrderManagementService.Models;
using OrderManagementService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagementService.Repository
{
    public interface IOrderRepository
    {
        CartStatus Display(string UserId);
        string Remove(string Myorderid);
        string Buy(string UserId);
        string AddToCart(Cart cart);
        CartStatus Invoice(string UserId);
        string AddInvoice(InvoiceView invoiceView);
    }
}

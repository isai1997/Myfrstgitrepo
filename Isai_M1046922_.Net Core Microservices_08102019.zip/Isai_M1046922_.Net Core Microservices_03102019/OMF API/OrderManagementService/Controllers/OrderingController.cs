﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrderManagementService.Models;
using OrderManagementService.Repository;
using OrderManagementService.ViewModels;

namespace OrderManagementService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderingController : ControllerBase
    {
        IOrderRepository orderRepository;
        public OrderingController(IOrderRepository _orderRepository)
        {
            orderRepository = _orderRepository;
        }

        [HttpGet]
        [Route("CartAction")]
        public CartStatus CartAction(string UserId)
        {
            return orderRepository.Display(UserId);
        }
        /// <summary>
        /// Removing items from Cart
        /// </summary>
        /// <param name="CartId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("Remove")]
        public string Remove(string Myorderid)
        {
            return orderRepository.Remove(Myorderid);
        }
        /// <summary>
        /// Buy items from Cart action method
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Buy")]
        public string Buy(string UserId)
        {
            return orderRepository.Buy(UserId);
        }
        [HttpPost]
        [Route("AddToCart")]
        public string AddToCart(Cart cart)
        {
                return orderRepository.AddToCart(cart);
        }
        [HttpGet]
        [Route("Invoice")]
        public CartStatus Invoice(string UserId)
        {
            return orderRepository.Invoice(UserId);
        }
        [HttpPost]
        [Route("AddInvoice")]
        public string AddInvoice(InvoiceView invoiceView)
        {
            return orderRepository.AddInvoice(invoiceView);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagementService.ViewModels
{
    public class CartStatus
    {
        public List<CartView> statusList { get; set; }
        public string statusMessage { get; set; }
    }
}

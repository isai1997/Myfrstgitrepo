﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagementService.ViewModels
{
    public class CartView
    {
        public string Myorderid { get; set; }
        public string Itemname { get; set; }
        public int? Quantity { get; set; }
        public string Id { get; set; }
        public string UserId { get; set; }
        public double? Price { get; set; }

        public string Restaurantname { get; set; }


    }
}

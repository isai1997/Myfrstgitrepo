﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderManagementService.ViewModels
{
    public class InvoiceView
    {
        public string PlacedOrderid { get; set; }
        public string UserId { get; set; }
        public string Myorderid { get; set; }
    }
}

﻿using CommonService.Models;
using CommonService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantSearchService.Repository
{
    public class SearchRepository : ISearchRepository
    {
        OrdermyfoodContext db;
        public SearchRepository(OrdermyfoodContext _db)
        {
            db = _db;
        }
        public SearchViewStatus Searchhome(string searchType, string searchText)
        {
            SearchViewStatus ob = new SearchViewStatus();
            List<SearchHome> model = new List<SearchHome>();
            try
            {
                if (searchType != null && searchText != null)
                {

                    if (searchType.ToLower() == "restaurant")
                    {
                        model = (from res in db.Restaurant
                                 from menu in db.Menu
                                 where res.RestaurantId==menu.RestaurantId && res.RestaurantName.ToLower().Contains(searchText.ToLower())
                                 select new SearchHome
                                 {
                                     RestaurantName = res.RestaurantName,
                                     Itemname = menu.Itemname,
                                     Cost = menu.Cost
                                 }).ToList();
                    }
                    else if (searchType.ToLower() == "menu")
                    {
                        model = (from res in db.Restaurant
                                 from menu in db.Menu
                                 where res.RestaurantId == menu.RestaurantId && menu.Itemname.ToLower().Contains(searchText.ToLower())
                                 select new SearchHome
                                 {
                                     RestaurantName = res.RestaurantName,
                                     Itemname = menu.Itemname,
                                     Cost = menu.Cost
                                 }).ToList();
                    }

                    else if (searchType.ToLower() == "location")
                    {
                        model = (from res in db.Restaurant
                                 from menu in db.Menu
                                 where res.RestaurantId == menu.RestaurantId && res.City.ToLower().Contains(searchText.ToLower())
                                 select new SearchHome
                                 {
                                     RestaurantName = res.RestaurantName,
                                     Itemname = menu.Itemname,
                                     Cost = menu.Cost
                                 }).ToList();
                    }
                    else if (searchType.ToLower() == "cuisine")
                    {
                        model = (from res in db.Restaurant
                                 from menu in db.Menu
                                 where res.RestaurantId == menu.RestaurantId && menu.Cuisine.ToLower().Contains(searchText.ToLower())
                                 select new SearchHome
                                 {
                                     RestaurantName = res.RestaurantName,
                                     Itemname = menu.Itemname,
                                     Cost = menu.Cost
                                 }).ToList();
                    }


                    ob.statuslist = model;
                    if (model.Count > 0)
                    {
                        ob.statusMessage = "Success";
                    }
                    else
                    {
                        ob.statusMessage = "No record found.!";
                    }
                }
                else
                {
                    ob.statusMessage = "Searchtype and Searchtext are invalid!";
                }
            }
            catch (Exception ex)
            {
                ob.statuslist = model;
                ob.statusMessage = ex.Message;
            }

            return ob;



        }
    }
}


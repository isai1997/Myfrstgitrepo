﻿using CommonService.Models;
using CommonService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantSearchService.Repository
{
    public interface ISearchRepository
    {
        SearchViewStatus Searchhome(string searchType, string searchText);
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CommonService.Models;
using CommonService.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantSearchService.Repository;

namespace RestaurantSearchService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        ISearchRepository searchRepository;
        public SearchController(ISearchRepository _searchRepository)
        {
            searchRepository = _searchRepository;
        }

        [HttpGet]
        public SearchViewStatus Autosearch(string searchType, string searchText)
        {
            return searchRepository.Searchhome(searchType, searchText);

        }

    }
}
﻿using CommonService.Models;
using CommonService.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReviewManagementSystem.Repository
{
    public interface IRatingRepository
    {
        Task<List<RatingView>> GetRatings();

        Task<int> AddRating(Rating rating);

        Task UpdateRating(Rating rating);
    }
}

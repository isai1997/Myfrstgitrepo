﻿using CommonService.Models;
using CommonService.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReviewManagementSystem.Repository
{
    public class RatingRepository :IRatingRepository
    {
        OrdermyfoodContext db;
        public RatingRepository(OrdermyfoodContext _db)
        {
            db = _db;
        }

        public async Task<List<RatingView>> GetRatings()
        {
            if (db != null)
            {
                return await (from p in db.Rating
                              from c in db.Restaurant
                              where p.RestaurantId == c.RestaurantId
                              select new RatingView
                              {
                                  Restaurantname = c.RestaurantName,
                                  Ratings = p.Rating1,
                                  Comment = p.Comment
                              }).ToListAsync();
            }

            return null;
        }
        public async Task<int> AddRating(Rating rating)
        {
            if (db != null)
            {
                await db.Rating.AddAsync(rating);
                await db.SaveChangesAsync();

                return rating.Id;
            }

            return 0;
        }
        public async Task UpdateRating(Rating rating)
        {
            if (db != null)
            {

                db.Rating.Update(rating);


                await db.SaveChangesAsync();
            }
        }
    }
}

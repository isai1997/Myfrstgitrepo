﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CommonService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ReviewManagementSystem.Repository;

namespace ReviewManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatingController : ControllerBase
    {
        IRatingRepository ratingRepository;
        public RatingController(IRatingRepository _ratingRepository)
        {
            ratingRepository = _ratingRepository;
        }

        [HttpGet]
        [Route("GetRatings")]
        public async Task<IActionResult> GetRatings()
        {
            try
            {
                var ratings = await ratingRepository.GetRatings();
                if (ratings == null)
                {
                    return NotFound();
                }

                return Ok(ratings);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [Route("AddRating")]
        public async Task<IActionResult> AddRating([FromBody]Rating model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var ratingId = await ratingRepository.AddRating(model);
                    if (ratingId > 0)
                    {
                        return Ok(ratingId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }



        [HttpPost]
        [Route("UpdateRating")]
        public async Task<IActionResult> UpdateRating([FromBody]Rating model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await ratingRepository.UpdateRating(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }

    }
}
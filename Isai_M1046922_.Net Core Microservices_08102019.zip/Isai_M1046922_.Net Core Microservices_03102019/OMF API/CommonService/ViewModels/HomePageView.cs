﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonService.ViewModels
{
   public class HomePageView
    {
        public string RestaurantName { get; set; }
        public string Itemname { get; set; }
        public double Cost { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonService.ViewModels
{
    public class RatingView
    {
        public string Restaurantname { get; set; }
        public double? Ratings { get; set; }

        public string Comment { get; set; }
    }
}

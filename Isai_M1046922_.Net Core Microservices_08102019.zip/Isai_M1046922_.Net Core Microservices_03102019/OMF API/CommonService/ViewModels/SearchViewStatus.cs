﻿using CommonService.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommonService.ViewModels
{
   public class SearchViewStatus
    {
        public string statusMessage { get; set; }
        public List<SearchHome> statuslist { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class PlacedOrder
    {
        public string PlacedOrderid { get; set; }
        public string Myorderid { get; set; }

        public string UserId { get; set; }

        public virtual Myorder Myorder { get; set; }
        public virtual Users Users { get; set; }
    }
}

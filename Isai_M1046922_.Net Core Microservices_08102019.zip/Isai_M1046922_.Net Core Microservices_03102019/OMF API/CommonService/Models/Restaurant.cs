﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class Restaurant
    {
        public Restaurant()
        {
            Menu = new HashSet<Menu>();
            Rating = new HashSet<Rating>();
        }

        public string RestaurantId { get; set; }
        public string RestaurantName { get; set; }
        public string Category { get; set; }
        public string City { get; set; }

        public virtual ICollection<Menu> Menu { get; set; }
        public virtual ICollection<Rating> Rating { get; set; }
    }
}

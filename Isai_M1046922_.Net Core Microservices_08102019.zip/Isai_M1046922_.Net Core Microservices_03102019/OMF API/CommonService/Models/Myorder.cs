﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class Myorder
    {
        public Myorder()
        {
            PlacedOrder = new HashSet<PlacedOrder>();
        }

        public string Myorderid { get; set; }
        public string Itemname { get; set; }
        public int? Quantity { get; set; }
        public string RestaurantId { get; set; }
        public string Id { get; set; }
        public string UserId { get; set; }
        public bool? PayStatus { get; set; }

        public virtual Menu IdNavigation { get; set; }
        public virtual Restaurant Restaurant { get; set; }
        public virtual Users User { get; set; }
        public virtual ICollection<PlacedOrder> PlacedOrder { get; set; }
    }
}

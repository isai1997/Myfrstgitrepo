﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class Rating
    {
        public int Id { get; set; }
        public double? Rating1 { get; set; }
        public string Comment { get; set; }
        public string UserId { get; set; }
        public string RestaurantId { get; set; }

        public virtual Restaurant Restaurant { get; set; }
        public virtual Users User { get; set; }
    }
}

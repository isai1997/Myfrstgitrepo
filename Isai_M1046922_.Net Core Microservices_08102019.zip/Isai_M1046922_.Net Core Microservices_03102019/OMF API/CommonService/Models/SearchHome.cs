﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonService.Models
{
   public class SearchHome
    {
        public string RestaurantName { get; set; }
        public string Itemname { get; set; }
        public double Cost { get; set; }
      
       
    }
}

﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class Users
    {
        public Users()
        {
            Myorder = new HashSet<Myorder>();
            Rating = new HashSet<Rating>();
            PlacedOrder = new HashSet<PlacedOrder>();
        }

        public string UserId { get; set; }
        public string EmailId { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public bool IsVerified { get; set; }

        public virtual ICollection<Myorder> Myorder { get; set; }
        public virtual ICollection<Rating> Rating { get; set; }
        public  virtual ICollection<PlacedOrder> PlacedOrder { get; set; }
    }
}

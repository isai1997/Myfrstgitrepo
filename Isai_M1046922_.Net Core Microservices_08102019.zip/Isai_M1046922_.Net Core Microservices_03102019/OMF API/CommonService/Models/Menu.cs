﻿using System;
using System.Collections.Generic;

namespace CommonService.Models
{
    public partial class Menu
    {
        public Menu()
        {
            Myorder = new HashSet<Myorder>();
        }

        public string Id { get; set; }
        public string Itemname { get; set; }
        public double Cost { get; set; }
        public string Cuisine { get; set; }
        public string RestaurantId { get; set; }

        public virtual Restaurant Restaurant { get; set; }
        public virtual ICollection<Myorder> Myorder { get; set; }
    }
}

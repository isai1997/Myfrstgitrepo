﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CommonService.Models
{
    public partial class OrdermyfoodContext : DbContext
    {
        public OrdermyfoodContext()
        {
        }

        public OrdermyfoodContext(DbContextOptions<OrdermyfoodContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Menu> Menu { get; set; }
        public virtual DbSet<Myorder> Myorder { get; set; }
        public virtual DbSet<PlacedOrder> PlacedOrder { get; set; }
        public virtual DbSet<Rating> Rating { get; set; }
        public virtual DbSet<Restaurant> Restaurant { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=A2ML29935;Initial Catalog=Ordermyfood;Integrated Security=False;User ID=sa;Password=Pari@1965");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.2-servicing-10034");

            modelBuilder.Entity<Menu>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Itemname)
                    .IsRequired()
                    .HasColumnName("itemname")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.RestaurantId)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.Restaurant)
                    .WithMany(p => p.Menu)
                    .HasForeignKey(d => d.RestaurantId)
                    .HasConstraintName("FK__Menu__Restaurant__66603565");
            });

            modelBuilder.Entity<Myorder>(entity =>
            {
                entity.HasKey(e => e.Myorderid)
                    .HasName("PK__Myorder__3B18EC0CA5224C51");

                entity.Property(e => e.Myorderid)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Id)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdNavigation)
                    .WithMany(p => p.Myorder)
                    .HasForeignKey(d => d.Id)
                    .HasConstraintName("FK__Myorder__Id__693CA210");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Myorder)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Myorder__UserId__6A30C649");
            });

            modelBuilder.Entity<PlacedOrder>(entity =>
            {
                entity.Property(e => e.PlacedOrderid)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Myorderid)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.Myorder)
                    .WithMany(p => p.PlacedOrder)
                    .HasForeignKey(d => d.Myorderid)
                    .HasConstraintName("FK__PlacedOrd__Myord__6FE99F9F");
            });

            modelBuilder.Entity<Rating>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Comment)
                    .HasColumnName("comment")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Rating1).HasColumnName("Rating");

                entity.Property(e => e.RestaurantId)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.Restaurant)
                    .WithMany(p => p.Rating)
                    .HasForeignKey(d => d.RestaurantId)
                    .HasConstraintName("FK__Rating__Restaura__5070F446");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Rating)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__Rating__UserId__4F7CD00D");
            });

            modelBuilder.Entity<Restaurant>(entity =>
            {
                entity.Property(e => e.RestaurantId)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RestaurantName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Users__1788CC4CB08BB01A");

                entity.Property(e => e.UserId)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });
        }
    }
}
